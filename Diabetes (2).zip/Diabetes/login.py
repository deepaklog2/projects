import pandas as pd
import os
import hashlib
import streamlit as st

# Define the path to the user database CSV file
USER_DB_FILE = 'users.csv'

def init_user_db():
    """Initialize the user database if it does not exist."""
    if not os.path.exists(USER_DB_FILE):
        df = pd.DataFrame(columns=['username', 'password'])
        df.to_csv(USER_DB_FILE, index=False)

def hash_password(password):
    """Hash a password using SHA-256."""
    return hashlib.sha256(password.encode()).hexdigest()

def add_user(username, password):
    """Add a new user to the database."""
    df = pd.read_csv(USER_DB_FILE) if os.path.exists(USER_DB_FILE) and os.path.getsize(USER_DB_FILE) > 0 else pd.DataFrame(columns=['username', 'password'])
    
    if username not in df['username'].values:
        hashed_password = hash_password(password)
        new_user = pd.DataFrame([[username, hashed_password]], columns=['username', 'password'])
        df = pd.concat([df, new_user], ignore_index=True)
        df.to_csv(USER_DB_FILE, index=False)
        return True
    return False

def authenticate_user(username, password):
    """Authenticate a user by checking username and password."""
    if os.path.exists(USER_DB_FILE) and os.path.getsize(USER_DB_FILE) > 0:
        df = pd.read_csv(USER_DB_FILE)
    else:
        return False
    
    if username in df['username'].values:
        hashed_password = hash_password(password)
        return hashed_password in df[df['username'] == username]['password'].values
    return False

def login_page():
    st.title("Login")

    login_username = st.text_input("Username")
    login_password = st.text_input("Password", type="password")

    if st.button("Login"):
        if authenticate_user(login_username, login_password):
            st.session_state.logged_in = True
            st.session_state.username = login_username
            st.session_state.page = "app"  # Redirect to app page
        else:
            st.error("Invalid username or password.")

def register_page():
    st.title("Register")

    reg_username = st.text_input("New Username")
    reg_password = st.text_input("New Password", type="password")

    if st.button("Register"):
        if add_user(reg_username, reg_password):
            st.success("User registered successfully! Please log in.")
            st.session_state.page = "login"  # Go to login page after registration
        else:
            st.error("Username already exists.")

def main():
    init_user_db()

    if 'page' not in st.session_state:
        st.session_state.page = "register"  # Start with registration page

    if 'logged_in' in st.session_state and st.session_state.logged_in:
        st.session_state.page = "app"  # Redirect to app.py when logged in

    if st.session_state.page == "login":
        login_page()
    elif st.session_state.page == "register":
        register_page()
    elif st.session_state.page == "app":
        st.write("You are now logged in. Please visit the [app](http://localhost:8501) to access the main application.")  # Provide a link to the app

if __name__ == "__main__":
    main()