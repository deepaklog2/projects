import numpy as np
import pandas as pd
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn import svm
from sklearn.preprocessing import StandardScaler
from PIL import Image
import logging
import PyPDF2
import re
import os
import smtplib
from dotenv import load_dotenv
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Load environment variables from .env file
load_dotenv()

# Configure logging for debugging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger()

# Fetch environment variables
EMAIL_PASSWORD = os.getenv('EMAIL_PASSWORD')
SENDER_EMAIL = "16gomathimsc@gmail.com"

def check_login():
    """Check if user is logged in; if not, show login message."""
    if 'logged_in' not in st.session_state or not st.session_state.logged_in:
        st.write("Please log in to access the app.")
        st.write("[Log In](http://localhost:8501/login)")
        st.stop()

def load_data():
    try:
        logger.debug("Loading dataset...")
        diabetes_df = pd.read_csv('diabetes.csv')
        logger.debug("Dataset loaded successfully.")
        return diabetes_df
    except FileNotFoundError as e:
        st.error(f"Error: {e}")
        logger.error(f"FileNotFoundError: {e}")
        st.stop()
    except Exception as e:
        st.error(f"An unexpected error occurred: {e}")
        logger.error(f"Unexpected error: {e}")
        st.stop()

def preprocess_data(df):
    try:
        logger.debug("Preprocessing data...")
        X = df.drop('Outcome', axis=1)
        y = df['Outcome']
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        logger.debug("Data preprocessing completed.")
        return X_scaled, y, scaler
    except Exception as e:
        st.error(f"An error occurred during preprocessing: {e}")
        logger.error(f"Preprocessing error: {e}")
        st.stop()

def train_model(X_train, y_train):
    try:
        logger.debug("Training model...")
        model = svm.SVC(kernel='linear')
        model.fit(X_train, y_train)
        logger.debug("Model training completed.")
        return model
    except Exception as e:
        st.error(f"An error occurred during model training: {e}")
        logger.error(f"Model training error: {e}")
        st.stop()

def get_precautionary_advice(features):
    glucose, bp, insulin, skinthickness, bmi, dpf = features[1:7]
    
    advice = []

    # Glucose Level
    if glucose > 125:
        advice.append("• High glucose levels can be managed by reducing sugar intake, eating a balanced diet, and increasing physical activity.")
        advice.append("• Regular monitoring of blood sugar levels is important.")
        advice.append("• Consult a healthcare professional for personalized advice.")
        advice.append("• Consider joining a diabetes education program for more guidance.")
        advice.append("• Monitor glucose levels regularly to prevent complications.")

    # Blood Pressure
    if bp > 80:
        advice.append("• High blood pressure can be managed by reducing salt intake, exercising regularly, and avoiding stress.")
        advice.append("• Monitor blood pressure frequently and take medications if prescribed.")
        advice.append("• Maintain a healthy weight and reduce alcohol consumption.")
        advice.append("• Regular check-ups with a healthcare provider are recommended.")

    # Insulin Level
    if insulin > 25:
        advice.append("• High insulin levels can be controlled by following a healthy diet, maintaining a healthy weight, and avoiding excessive sugar intake.")
        advice.append("• Consider regular physical activity to improve insulin sensitivity.")
        advice.append("• Consult a dietitian for a personalized meal plan.")
        advice.append("• Discuss with a healthcare provider if medication adjustments are needed.")

    # Skin Thickness
    if skinthickness > 30:
        advice.append("• Increased skin thickness can be managed by improving diet and increasing physical activity.")
        advice.append("• Monitor skin changes and consult a dermatologist if needed.")
        advice.append("• Regular exercise and a balanced diet are key.")
        advice.append("• Check for other potential underlying conditions with a healthcare provider.")

    # BMI
    if bmi > 30:
        advice.append("• A high BMI indicates obesity. Consider a balanced diet and regular exercise to maintain a healthy weight.")
        advice.append("• Aim for gradual weight loss through lifestyle changes.")
        advice.append("• Consult a healthcare provider for a weight management plan.")
        advice.append("• Avoid fad diets and focus on sustainable changes.")
        advice.append("• Incorporate both aerobic and strength training exercises.")

    # Diabetes Pedigree Function
    if dpf > 0.5:
        advice.append("• A high Diabetes Pedigree Function indicates a family history of diabetes. Maintain a healthy lifestyle and get regular check-ups.")
        advice.append("• Consider genetic counseling if there is a significant family history.")
        advice.append("• Stay informed about diabetes prevention strategies.")
        advice.append("• Monitor your health regularly for early signs of diabetes.")

    return advice

def process_uploaded_pdf(uploaded_file):
    try:
        reader = PyPDF2.PdfFileReader(uploaded_file)
        first_page = reader.getPage(0).extract_text()
        
        # Extracting values from the PDF
        values = {
            'Pregnancies': None,
            'Glucose': None,
            'Blood Pressure': None,
            'Skin Thickness': None,
            'Insulin': None,
            'BMI': None,
            'Diabetes Pedigree Function': None,
            'Age': None
        }
        
        for key in values.keys():
            match = re.search(f'{key}:\s*(\d+\.?\d*)', first_page)
            if match:
                values[key] = float(match.group(1))
        
        # Convert extracted values to a list
        return list(values.values())
    except Exception as e:
        logger.error(f"PDF processing error: {e}")
        st.error("Error processing PDF. Please ensure the format is correct.")
        return None

def send_email(subject, body, to_email):
    try:
        # Set up the email server and login
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(SENDER_EMAIL, EMAIL_PASSWORD)
        
        # Create the email message
        msg = MIMEMultipart()
        msg['From'] = SENDER_EMAIL
        msg['To'] = to_email
        msg['Subject'] = subject
        
        msg.attach(MIMEText(body, 'plain'))
        
        # Send the email
        server.send_message(msg)
        server.quit()
        st.success('Your message has been sent! We will get back to you soon.')
    except Exception as e:
        logger.error(f"Email sending error: {e}")
        st.error("Failed to send email. Please try again.")

def app():
    # Check if the user is logged in
    check_login()

    # Load the diabetes dataset
    diabetes_df = load_data()

    # Preprocess data
    X_scaled, y, scaler = preprocess_data(diabetes_df)

    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=1)

    # Train the SVM model
    model = train_model(X_train, y_train)

    # Create the Streamlit app
    try:
        img = Image.open("img.jpg")
        img = img.resize((200, 200))
        st.image(img, caption="Diabetes Image", width=200)
    except FileNotFoundError as e:
        st.error(f"Error: {e}")
        logger.error(f"Image FileNotFoundError: {e}")
        st.stop()
    except Exception as e:
        st.error(f"An unexpected error occurred: {e}")
        logger.error(f"Unexpected error: {e}")
        st.stop()

    st.title('Diabetes Prediction')

    # User profile section
    st.sidebar.title('User Profile')
    st.sidebar.write(f"**Username:** {st.session_state.username}")

    # Create the input form for the user to input new data
    st.sidebar.title('Input Features')
    preg = st.sidebar.slider('Pregnancies', 0, 17, 3)
    glucose = st.sidebar.slider('Glucose', 0, 199, 117)
    bp = st.sidebar.slider('Blood Pressure', 0, 122, 72)
    skinthickness = st.sidebar.slider('Skin Thickness', 0, 99, 23)
    insulin = st.sidebar.slider('Insulin', 0, 846, 30)
    bmi = st.sidebar.slider('BMI', 0.0, 67.1, 32.0)
    dpf = st.sidebar.slider('Diabetes Pedigree Function', 0.078, 2.42, 0.3725, 0.001)
    age = st.sidebar.slider('Age', 21, 81, 29)

    # Log input data for debugging
    input_data = [preg, glucose, bp, skinthickness, insulin, bmi, dpf, age]
    logger.debug(f"Input data: {input_data}")

    # Make a prediction based on the user input
    reshaped_input_data = np.array(input_data).reshape(1, -1)
    scaled_input_data = scaler.transform(reshaped_input_data)
    prediction = model.predict(scaled_input_data)

    # Display the prediction to the user
    st.write('Based on the input features, the model predicts:')
    if prediction == 1:
        st.warning('This person has diabetes.')
    else:
        st.success('This person does not have diabetes.')
        st.write("• Your values are within the normal range. Continue with a healthy lifestyle.")

    # Generate precautionary advice
    precautionary_advice = get_precautionary_advice(input_data)
    
    # Display the precautionary advice if there's any
    if prediction == 1:
        st.header('Health Precautionary Advice')
        st.write(" ".join(precautionary_advice))

    # File upload section
    st.header('Upload Patient Result File')
    uploaded_file = st.file_uploader("Choose a PDF file", type="pdf")

    if uploaded_file is not None:
        values = process_uploaded_pdf(uploaded_file)
        if values:
            st.write("Extracted values from the PDF:")
            st.write(f"Pregnancies: {values[0]}")
            st.write(f"Glucose: {values[1]}")
            st.write(f"Blood Pressure: {values[2]}")
            st.write(f"Skin Thickness: {values[3]}")
            st.write(f"Insulin: {values[4]}")
            st.write(f"BMI: {values[5]}")
            st.write(f"Diabetes Pedigree Function: {values[6]}")
            st.write(f"Age: {values[7]}")

            # Predict based on extracted values
            reshaped_input_data = np.array(values).reshape(1, -1)
            scaled_input_data = scaler.transform(reshaped_input_data)
            prediction = model.predict(scaled_input_data)
            
            if prediction == 1:
                st.warning('The uploaded data indicates diabetes.')
            else:
                st.success('The uploaded data indicates no diabetes.')
                st.write("• Your values are within the normal range. Continue with a healthy lifestyle.")

            # Generate precautionary advice based on extracted values
            precautionary_advice = get_precautionary_advice(values)
            if prediction == 1:
                st.header('Health Precautionary Advice')
                st.write(" ".join(precautionary_advice))

    # Contact Form
    st.header('Contact Us')
    with st.form(key='contact_form'):
        st.write("If you have any questions or need assistance, please contact us using the form below:")
        name = st.text_input('Name')
        email = st.text_input('Email')
        message = st.text_area('Message')
        
        # Contact information
        st.write("For urgent inquiries, please call us at +91-6381687588 or email us at 16gomathimsc@gmail.com.")

        # Submit button
        submit_button = st.form_submit_button(label='Submit')
        if submit_button:
            # Send email
            subject = f"Contact Form Submission from {name}"
            body = f"Name: {name}\nEmail: {email}\nMessage: {message}"
            recipient_email = "16gomathimsc@gmail.com"
            send_email(subject, body, recipient_email)

if __name__ == '__main__':
    app()